import { config } from 'dotenv';
config();

import '@/ai/flows/lead-scoring.ts';