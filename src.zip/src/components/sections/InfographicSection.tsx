// import Image from 'next/image';
// import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

// export default function InfographicSection() {
//   return (
//     <section className="py-16 md:py-24 bg-muted/30">
//       <div className="container">
//         <div className="text-center mb-12">
//           <h2 className="text-3xl md:text-4xl font-bold text-primary">أهمية التأمين في أرقام</h2>
//           <p className="mt-4 text-lg text-foreground/80 max-w-2xl mx-auto">
//             نظرة على إحصائيات حوادث السيارات في مصر وأهمية وجود تغطية تأمينية مناسبة.
//           </p>
//         </div>
//         <Card className="shadow-lg overflow-hidden">
//           <CardHeader>
//             <CardTitle className="text-2xl text-center">إحصائيات حوادث السيارات وأهمية التأمين في مصر</CardTitle>
//             <CardDescription className="text-center">
//               البيانات التالية توضح الحاجة الماسة للتأمين لحماية استثماراتك وسلامتك.
//             </CardDescription>
//           </CardHeader>
//           <CardContent className="flex justify-center items-center p-6">
//             {/* Placeholder for infographic */}
//             <div className="w-full max-w-4xl aspect-[16/9] relative bg-gray-200 rounded-lg flex items-center justify-center">
//                 <Image 
//                     src="https://placehold.co/800x450.png" 
//                     alt="إنفوجرافيك إحصائيات حوادث السيارات" 
//                     layout="fill"
//                     objectFit="cover"
//                     className="rounded-lg"
//                     data-ai-hint="statistics infographic"
//                 />
//                 <p className="absolute text-xl text-white bg-black/50 p-4 rounded">سيتم إضافة الإنفوجرافيك قريباً</p>
//             </div>
//           </CardContent>
//         </Card>
//         <div className="mt-8 text-center text-sm text-muted-foreground">
//           <p>* البيانات المعروضة هي لأغراض توضيحية وسيتم تحديثها بإحصائيات فعلية.</p>
//         </div>
//       </div>
//     </section>
//   );
// }
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertTriangle, Shield, TrendingDown, Users, Car, Heart } from 'lucide-react';

export default function InfographicSection() {
  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary">أهمية التأمين في أرقام</h2>
          <p className="mt-4 text-lg text-foreground/80 max-w-2xl mx-auto">
            نظرة على إحصائيات حوادث السيارات في مصر وأهمية وجود تغطية تأمينية مناسبة.
          </p>
        </div>

        {/* Main Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="text-center border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <AlertTriangle className="h-12 w-12 text-red-600" />
              </div>
              <div className="text-3xl font-bold text-red-700 mb-2">5,861</div>
              <p className="text-sm text-red-600">وفاة بسبب حوادث الطرق في مصر عام 2023</p>
            </CardContent>
          </Card>

          <Card className="text-center border-orange-200 bg-orange-50">
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <Users className="h-12 w-12 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-orange-700 mb-2">42</div>
              <p className="text-sm text-orange-600">وفاة لكل 100,000 نسمة - من أعلى المعدلات بالمنطقة</p>
            </CardContent>
          </Card>

          <Card className="text-center border-green-200 bg-green-50">
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <TrendingDown className="h-12 w-12 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-green-700 mb-2">24.5%</div>
              <p className="text-sm text-green-600">انخفاض في الوفيات مقارنة بعام 2022</p>
            </CardContent>
          </Card>

          <Card className="text-center border-blue-200 bg-blue-50">
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <Shield className="h-12 w-12 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-blue-700 mb-2">37.3</div>
              <p className="text-sm text-blue-600">مليار جنيه حجم سوق التأمين العام في مصر 2023</p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Infographic */}
        <Card className="shadow-lg overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
            <CardTitle className="text-2xl text-center">إحصائيات شاملة حول السلامة المرورية والتأمين في مصر</CardTitle>
            <CardDescription className="text-blue-100 text-center">
              البيانات الرسمية توضح الحاجة الماسة للتأمين لحماية استثماراتك وسلامتك
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8">
            
            {/* Road Safety Section */}
            <div className="mb-12">
              <h3 className="text-xl font-bold text-center mb-8 flex items-center justify-center gap-2">
                <Car className="h-6 w-6 text-red-600" />
                إحصائيات السلامة المرورية
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="bg-red-50 p-6 rounded-lg border-l-4 border-red-500">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-red-700 font-semibold">الوفيات في 2023</span>
                      <span className="text-2xl font-bold text-red-800">5,861</span>
                    </div>
                    <div className="text-sm text-red-600">انخفاض من 7,762 في عام 2022</div>
                    <div className="w-full bg-red-200 rounded-full h-2 mt-2">
                      <div className="bg-red-600 h-2 rounded-full" style={{width: '75.5%'}}></div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded-lg border-l-4 border-orange-500">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-orange-700 font-semibold">معدل الوفيات</span>
                      <span className="text-2xl font-bold text-orange-800">42</span>
                    </div>
                    <div className="text-sm text-orange-600">لكل 100,000 نسمة - من أعلى المعدلات بالمنطقة</div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-yellow-50 p-6 rounded-lg border-l-4 border-yellow-500">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-yellow-700 font-semibold">أسباب الإصابات</span>
                      <span className="text-2xl font-bold text-yellow-800">46.8%</span>
                    </div>
                    <div className="text-sm text-yellow-600">من الإصابات بسبب حوادث السيارات</div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded-lg border-l-4 border-purple-500">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-purple-700 font-semibold">نسبة الذكور</span>
                      <span className="text-2xl font-bold text-purple-800">77%</span>
                    </div>
                    <div className="text-sm text-purple-600">من ضحايا حوادث الطرق على مستوى العالم</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Insurance Market Section */}
            <div className="mb-12">
              <h3 className="text-xl font-bold text-center mb-8 flex items-center justify-center gap-2">
                <Shield className="h-6 w-6 text-blue-600" />
                سوق التأمين في مصر
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-blue-200 bg-blue-50">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-blue-700 mb-2">37.3</div>
                    <p className="text-sm text-blue-600">مليار جنيه حجم السوق</p>
                    <p className="text-xs text-blue-500 mt-1">(1.2 مليار دولار)</p>
                  </CardContent>
                </Card>

                <Card className="border-green-200 bg-green-50">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-green-700 mb-2">19%</div>
                    <p className="text-sm text-green-600">معدل النمو السنوي المتوقع</p>
                    <p className="text-xs text-green-500 mt-1">2024-2028</p>
                  </CardContent>
                </Card>

                <Card className="border-purple-200 bg-purple-50">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-purple-700 mb-2">5.0</div>
                    <p className="text-sm text-purple-600">مليار دولار حجم السوق المتوقع</p>
                    <p className="text-xs text-purple-500 mt-1">بحلول 2028</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Safety Tips Section */}
            <div className="bg-gradient-to-br from-blue-50 to-green-50 p-8 rounded-lg">
              <h3 className="text-xl font-bold text-center mb-6 flex items-center justify-center gap-2">
                <Heart className="h-6 w-6 text-red-600" />
                لماذا التأمين ضروري؟
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <div className="text-2xl font-bold text-blue-600 mb-2">حماية مالية</div>
                  <p className="text-sm text-gray-600">تغطية تكاليف الحوادث والإصلاحات</p>
                </div>
                
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <div className="text-2xl font-bold text-green-600 mb-2">أمان قانوني</div>
                  <p className="text-sm text-gray-600">تجنب المسائل القانونية والغرامات</p>
                </div>
                
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <div className="text-2xl font-bold text-purple-600 mb-2">راحة البال</div>
                  <p className="text-sm text-gray-600">القيادة بثقة وأمان تام</p>
                </div>
                
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <div className="text-2xl font-bold text-orange-600 mb-2">خدمات طوارئ</div>
                  <p className="text-sm text-gray-600">مساعدة فورية على الطريق</p>
                </div>
              </div>
            </div>

          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>* البيانات مأخوذة من الجهاز المركزي للتعبئة العامة والإحصاء ومنظمة الصحة العالمية وتقارير السوق المحلية لعام 2023-2024</p>
        </div>
      </div>
    </section>
  );
}