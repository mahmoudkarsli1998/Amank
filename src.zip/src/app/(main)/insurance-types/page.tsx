import InsuranceTypesSection from '@/components/sections/InsuranceTypesSection';

export default function InsuranceTypesPage() {
  return (
    <>
      <InsuranceTypesSection />
    </>
  );
}
