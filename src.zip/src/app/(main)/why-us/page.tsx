import WhyChooseUsSection from '@/components/sections/WhyChooseUsSection';

export default function WhyUsPage() {
  return (
    <>
      <WhyChooseUsSection />
    </>
  );
}
